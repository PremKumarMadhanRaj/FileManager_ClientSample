(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["_content/Syncfusion.Blazor/scripts/sf-import-ie"],{

/***/ "./modules/sf-import-ie.js":
/*!*********************************!*\
  !*** ./modules/sf-import-ie.js ***!
  \*********************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports) {

window.sfBlazor = window.sfBlazor || {};

window.sfBlazor["import"] = function (url) {
  if (typeof url === 'string' && url.startsWith('./')) {
    url = document.baseURI + url.substr(2);
  }

  new Promise(function (resolve, reject) {
    var script = document.createElement('script');
    script.src = url;
    script.async = true;

    script.onload = function () {
      resolve(script);
    };

    script.onerror = function () {
      reject(script);
    };

    document.body.appendChild(script);
  });
};

/***/ })

}]);