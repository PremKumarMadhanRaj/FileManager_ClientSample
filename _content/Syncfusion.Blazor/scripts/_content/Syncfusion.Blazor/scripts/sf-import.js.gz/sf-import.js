(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["_content/Syncfusion.Blazor/scripts/sf-import"],{

/***/ "./modules/sf-import.js":
/*!******************************!*\
  !*** ./modules/sf-import.js ***!
  \******************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports) {

window.sfBlazor = window.sfBlazor || {};

window.sfBlazor["import"] = function (url) {
  if (typeof url === 'string' && url.startsWith('./')) {
    url = document.baseURI + url.substr(2);
  }

  return import(
  /* webpackIgnore: true */
  url);
};

/***/ })

}]);